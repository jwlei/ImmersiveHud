# 1.3.4
* Updated references

# 1.3.3
* Hotfix again lol, I'l test better in the future.

# 1.3.2
* Fix for partial compatibility with Minimal UI, added toggles to disable minimalUI elements, note that these should be disabled in both mods. E.g. If you want to use the vanilla healthbar, disable it in MinimalUI, and remove the checkmark for MinimalUI healthbar under Compatibility

# 1.3.1
* Hotfix for broken logic caused by experimental feature

# 1.3.0
* Added compatibility with Azumatt's Minimal UI, for foodbar see compatibility options

* Major reorganization of config settings for increased readability

# 1.2.0
* Added option to show healthbar on damage taken

* Added compatibility with AzuExtendedInventory

# 1.1.0
* Added option to hide KeyHints (The hotkey text at the bottom of the screen while using a tool/weapon)

# 1.0.0
* Initial release